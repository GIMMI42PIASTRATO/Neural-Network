# esercizio 1
# Modifica i pesi iniziali, cosa succede? Se li modifichi utilizzando numeri grandi ottieni la convergenza (cioè errore nullo)? Se no cosa puoi fare per avere un errore accettabile?
